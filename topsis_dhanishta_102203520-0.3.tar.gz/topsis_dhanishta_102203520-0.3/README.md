# Topsis-Dhanishta-102203520

This package implements the Topsis method for decision-making.

## Installation

You can install the package using pip:

```bash
pip install Topsis-Dhanishta-102203520
